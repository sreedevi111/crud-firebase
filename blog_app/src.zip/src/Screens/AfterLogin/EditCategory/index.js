import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const EditCategory = () => {
  return (
    <View>
      <Text>EditCategory
    
      </Text>
    </View>
  )
}

export default EditCategory

const styles = StyleSheet.create({})
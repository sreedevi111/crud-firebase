export const postReducer = () =>{
    
}
import { StyleSheet, Text, View, Dimensions } from 'react-native'
import React, {useState, useEffect} from 'react'
import MapView, {PROVIDER_GOOGLE} from 'react-native-maps';


const windowHeight = Dimensions.get('window').height;
const windowWidth = Dimensions.get('window').width;
const ASPECT_RATIO = windowWidth/windowHeight;
const LATITUDE_DElTA = 0.0992;
const LONGITUDE_DELTA = LATITUDE_DElTA * ASPECT_RATIO
const GoogleMaps = () => {

const initialRegion = {
  latitude: 37.78825,
  longitude: -122.4324,
  latitudeDelta: LATITUDE_DElTA,
  longitudeDelta: LONGITUDE_DELTA
}

const [position, setPosition] = useState({initialRegion});
const defaultValue ='';
const [ value, setValue] = useState(defaultValue)

console.log("Position::", position)

const applyNewValue = (newVal) => {
console.log('new Value:', newVal)
setValue(newVal)
}

  return (
    <View>
    <MapView
       provider={PROVIDER_GOOGLE} // remove if not using Google Maps
       style={styles.map}
       region={position}
       initialRegion={initialRegion}
       onRegionChange={applyNewValue}
     >
     </MapView>
    </View>
  )
}

export default GoogleMaps

const styles = StyleSheet.create({
    map: {
        width: windowWidth,
        height: windowHeight
      },
})